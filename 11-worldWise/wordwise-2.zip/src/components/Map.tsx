import {useEffect, useState} from "react";
import {
  MapContainer,
  Marker,
  Popup,
  TileLayer,
  useMap,
  useMapEvents,
} from "react-leaflet";
import {useNavigate} from "react-router-dom";
import {useCities} from "../contexts/CitiesContext";
import {useGeolocation} from "../hooks/useGeolocation";
import {useUrlPosition} from "../hooks/useUrlPosition";
import Button from "./Button";
import {flagemojiToPNG} from "./CityItem";
import styles from "./Map.module.css";

function Map() {
  const {cities} = useCities();
  const {lat: mapLat, lng: mapLng} = useUrlPosition();
  const [position, setPosition] = useState<{lat: number; lng: number}>({
    lat: 38.72757241420325,
    lng: -9.140539169311525,
  });
  const {
    isLoading: isLoadingPosition,
    position: geoLocationPosition,
    getPosition: getGeoLocationPosition,
  } = useGeolocation();
  useEffect(() => {
    if (mapLat && mapLng) {
      setPosition({lat: Number(mapLat), lng: Number(mapLng)});
    }
  }, [mapLat, mapLng]);
  useEffect(() => {
    if (geoLocationPosition?.lat && geoLocationPosition?.lng) {
      setPosition({
        lat: geoLocationPosition.lat,
        lng: geoLocationPosition.lng,
      });
    }
  }, [geoLocationPosition]);
  return (
    <div className={styles.mapContainer}>
      {!geoLocationPosition && (
        <Button type="position" onClick={getGeoLocationPosition}>
          {isLoadingPosition ? "Loading..." : "Use my location"}
        </Button>
      )}
      <MapContainer
        center={position}
        zoom={13}
        scrollWheelZoom={true}
        className={styles.map}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.fr/hot/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {cities.map((city) => (
          <Marker
            key={city.id}
            position={[city.position.lat, city.position.lng]}>
            <Popup>
              <span>{flagemojiToPNG(city.emoji)}</span>
              <div className={styles.popUp}>
                <span>{city.cityName}</span>
                <span>{city.notes}</span>
              </div>
            </Popup>
          </Marker>
        ))}
        <ChangePosition position={position} />
        <DetectClick />
      </MapContainer>
    </div>
  );
}
function ChangePosition({position}: {position: {lat: number; lng: number}}) {
  const map = useMap();
  map.setView(position, 10);
  return null;
}

function DetectClick() {
  const navigate = useNavigate();

  useMapEvents({
    click: (e) => navigate(`form?lat=${e.latlng.lat}&lng=${e.latlng.lng}`),
  });
  return null;
}
export default Map;
