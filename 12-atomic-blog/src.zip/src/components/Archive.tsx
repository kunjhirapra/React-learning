// components/Archive.tsx
import {memo, useState} from "react";
import {createRandomPost} from "../App";
import ArchiveList from "./ArchiveList";
import type {Post} from "../type";
import {usePosts} from "../methods/PostContext";

const Archive = memo(function Archive({show}: {show: boolean}) {
  const [archivePost] = useState(() =>
    Array.from({length: 10000}, () => createRandomPost())
  );

  const [showArchive, setShowArchive] = useState(show);

  const {onAddPost} = usePosts();

  return (
    <aside>
      <h2>Post archive</h2>

      <button onClick={() => setShowArchive((s) => !s)}>
        {showArchive ? "Hide archive" : "Show archive"}
      </button>

      {showArchive && (
        <ul>
          {archivePost.map((post: Post) => (
            <ArchiveList
              key={`${post.title}-${post.body}`}
              post={post}
              handleClick={() => onAddPost(post)}
            />
          ))}
        </ul>
      )}
    </aside>
  );
});

export {Archive};
