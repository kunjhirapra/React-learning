import {usePosts} from "../methods/PostContext";
import type {Post} from "../type";
import {PostItem} from "./List";

export function Posts() {
  const context = usePosts();

  const {posts} = context;
  return (
    <ul>
      {posts.map((post: Post, i: number) => (
        <PostItem key={`${post.title}-${post.body}-${i}`} post={post} />
      ))}
    </ul>
  );
}
