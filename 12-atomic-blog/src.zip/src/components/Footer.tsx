export function Footer() {
  return <footer>&copy; by The Atomic Blog ✌️</footer>;
}
