function ArchiveList({
  post,
  handleClick,
}: {
  post: {title: string; body: string};
  handleClick: (post: {title: string; body: string}) => void;
}) {
  return (
    <div>
      <li>
        <p>
          <strong>{post.title}:</strong> {post.body}
        </p>
        <button onClick={() => handleClick(post)}>Add as new post</button>
      </li>
    </div>
  );
}

export default ArchiveList;
