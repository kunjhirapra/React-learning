import {faker} from "@faker-js/faker";

import {Header} from "./components/Header";
import {Main} from "./components/Main";
import {Archive} from "./components/Archive";
import {Footer} from "./components/Footer";
import LightDarkButton from "./components/LightDarkButton";
import {PostProvider} from "./methods/PostProvider";

export function createRandomPost() {
  return {
    title: `${faker.hacker.adjective()} ${faker.hacker.noun()}`,
    body: faker.hacker.phrase(),
  };
}

function App() {
  return (
    <section>
      <LightDarkButton />
      <PostProvider>
        <Header />
        <Main />
        <Archive show={false} />
        <Footer />
      </PostProvider>
    </section>
  );
}

export default App;
